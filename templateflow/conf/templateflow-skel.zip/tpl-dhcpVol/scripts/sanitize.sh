#!/bin/bash
# Run sanitize.py.
python sanitize.py
